/*
Copyright (C) 2017  sergio soriano

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>

 */
package com.example.sergio.notas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private EditText n1;
    private EditText n2;
    private EditText n3;
    private EditText n4;
    private EditText e1;
    private EditText e2;
    private EditText e3;
    private EditText e4;
    private Button calcular;
    private Button btn_inf;

    private TextView  resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        n1 =(EditText) findViewById(R.id.epr1);
        n2 =(EditText) findViewById(R.id.epe1);
        n3 =(EditText) findViewById(R.id.epr2);
        n4 =(EditText) findViewById(R.id.epe2);

        e1 =(EditText) findViewById(R.id.eva1);
        e2 =(EditText) findViewById(R.id.eva2);
        e3 =(EditText) findViewById(R.id.eva3);
        e4 =(EditText) findViewById(R.id.eva4);

        calcular = (Button) findViewById(R.id.boton_calcular);
        resultado = (TextView) findViewById(R.id.id_resultado);

        btn_inf = (Button) findViewById(R.id.btn_informacion);

        btn_inf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,SecondActivity.class));
            }
        });

    }

    public void calcular(View v){

            double notepr1 = 10*(0.10*Integer.valueOf(n1.getText().toString()))/100;
            double notepe1 = 15*(0.10*Integer.valueOf(n2.getText().toString()))/100;
            double notepr2 = 20*(0.10*Integer.valueOf(n3.getText().toString()))/100;
            double notepe2 = 25*(0.10*Integer.valueOf(n4.getText().toString()))/100;
            double evas = 30*(0.10*((Integer.valueOf(e1.getText().toString())+Integer.valueOf(e2.getText().toString())+
                    Integer.valueOf(e3.getText().toString())+Integer.valueOf(e4.getText().toString()))/4))/100;

            double suma = notepr1+notepe1+notepr2+notepe2+evas;
            suma = Math.round(suma*Math.pow(10,2))/Math.pow(10,2);

            resultado.setText(String.valueOf(suma));
            Toast.makeText(getApplicationContext(), String.valueOf(suma), Toast.LENGTH_LONG).show();
    }
}
